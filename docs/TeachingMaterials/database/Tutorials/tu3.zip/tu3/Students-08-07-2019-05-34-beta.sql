-- Generation time: Mon, 08 Jul 2019 05:34:47 +0000

INSERT INTO `Students` VALUES 
('1','Rosalee'),
('2','Osborne'),
('3','Alvah'),
('4','Terry'),
('5','Giovani'),
('6','Lauryn'),
('7','Dell'),
('8','Lambert'),
('9','Hailee'),
('10','Charlene'); 